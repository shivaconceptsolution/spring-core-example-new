package scs;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class ClientCode {

	public static void main(String[] args) 
	{
		ClassPathResource res = new ClassPathResource("applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		Object o= factory.getBean("stu");
		Student s = (Student)o;
		System.out.println(s.getRno() + " "+s.getSname());
	}

}
